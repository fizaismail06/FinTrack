# FinTrack — your income, expense & net worth app

This is a installable mobile web app (PWA) built from your "Income & Expenses (Responses)" Google Sheet. All 1,333 income entries and 5,924 expense entries since 2020 are pre-loaded, and your bank balances / net worth match your existing Dashboard tab.

## Why a web app instead of a Play Store app
Building a native Android app requires Android Studio, the Android SDK, and Google's build servers to compile an APK — none of which are available in this sandboxed environment, so there'd be no way to verify a native build actually works. This app uses the same technology as a native app (installs to your home screen, works offline, full-screen, no browser bar) but is something I could fully build and test myself. If you later want a true native APK, the logic here can be ported to Android Studio (Kotlin) — just ask.

## How to install it on your phone (recommended: ~3 minutes)
A "Add to Home Screen" install only fully works (offline support, icon, splash screen) when the files are served over `https://`, not opened directly from a downloaded folder. The easiest free option:

1. Go to **github.com**, create a free account if needed, and create a new **public** repository (e.g. `fintrack`).
2. Upload all 8 files from this folder (`index.html`, `app.css`, `app.js`, `seed-data.js`, `manifest.json`, `service-worker.js`, `icon-192.png`, `icon-512.png`) directly into the root of that repository (drag-and-drop on the GitHub website works fine).
3. In the repo, go to **Settings → Pages**, set "Source" to the `main` branch / root folder, and save. GitHub gives you a URL like `https://yourname.github.io/fintrack/`.
4. Open that URL on your **Android phone in Chrome**. Tap the **⋮ menu → Add to Home screen / Install app**.
5. Open it from your home screen — it now behaves like a normal app icon, opens full-screen, and works without internet.

(Netlify Drop — netlify.com/drop — is an even faster alternative: just drag this folder onto the page and it gives you a live link instantly, no account needed for a quick test.)

## Quick local test (no install)
You can also just open `index.html` directly by tapping it in a file manager or emailing it to yourself and opening it in Chrome. Everything works the same way — you just won't get the offline/installed-app behaviour until it's hosted on https.

## Syncing across multiple devices (cloud sync + login)
You can now sign in and keep the app in sync across your phone, tablet, etc. This uses **Firebase** (a free Google service) — there's no server for you to run, but you do need to create your own free Firebase project once (about 5 minutes), because the app can't share a login system across everyone who downloads it.

### One-time setup
1. Go to **console.firebase.google.com**, sign in with any Google account, and click **Add project**. Give it any name (e.g. "fintrack"). You can skip/disable Google Analytics — not needed.
2. In the left sidebar, go to **Build → Authentication → Get started**, then enable the **Email/Password** sign-in provider.
3. Go to **Build → Firestore Database → Create database**. Pick any region close to you, and start in **production mode**.
4. Still in Firestore, open the **Rules** tab, replace the contents with the rules below, and click **Publish**:
   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /fintrack_users/{uid} {
         allow read, write: if request.auth != null && request.auth.uid == uid;
         match /{subcollection}/{docId} {
           allow read, write: if request.auth != null && request.auth.uid == uid;
         }
       }
     }
   }
   ```
   This makes sure each person can only ever read or write their own data — nobody else's. The `match /{subcollection}/{docId}` block covers the per-year income/expense documents described below.

   **If you already set up Firebase before this update:** your existing rules only covered the top-level document, not the new per-year subcollections — open Firestore → **Rules** again and replace them with the version above, or syncing will fail with a "permission denied" error.
5. Click the **gear icon → Project settings**, scroll to **"Your apps"**, click the **`</>`  (Web)** icon, give the app any nickname, and register it. Firebase will show you a `firebaseConfig` object like:
   ```
   { "apiKey": "...", "authDomain": "...", "projectId": "...", "storageBucket": "...", "messagingSenderId": "...", "appId": "..." }
   ```
   Copy that whole object.

### In the FinTrack app
1. Open **Settings → Cloud sync (multi-device) → Set up cloud sync**, paste the config object you copied, and tap **Save & connect**.
2. Tap **Sign up**, and create an email + password (this is just your own private login for your own Firebase project — nobody else can see it).
3. On your other device(s), install the app the same way, do step 1 with the **same config**, then tap **Log in** with the same email/password. Your data syncs automatically from then on.

### How syncing behaves
- Changes you make are pushed to the cloud a couple of seconds after you make them, and pulled to your other signed-in devices automatically (you'll see a "Synced from another device" toast).
- The very first time you log in on a *new* device, if the cloud already has data, you'll be asked to choose: keep this device's data, or load the cloud's data. After that one-time choice, syncing is automatic both ways.
- This is built for one person using a couple of devices, not simultaneous multi-user editing — if you somehow edit offline on two devices at the same time, whichever reconnects and syncs last will overwrite the other's changes from that offline window. For normal day-to-day single-person use this won't come up.
- Your data is stored as one small "profile" document plus one document per calendar year for income and per calendar year for expenses — so no matter how many years of history you accumulate, each document stays small and you'll never approach Firestore's per-document size limit. All your history since 2020 is fetched and shown in full; nothing is paged or truncated.
- Anyone with your app's URL could technically create their own separate login on your Firebase project — their data would be fully isolated from yours by the security rules above, but it would use a little of your free quota. For a personal tool this is a very low-risk, low-likelihood scenario; if you'd rather close it off entirely, you can disable "Email/Password" self-serve sign-up later in the Firebase console and create accounts manually instead.
- Cloud sync is entirely optional — if you never set it up, the app works exactly as before, fully offline, on a single device.

## Privacy: who can see or touch this if someone finds the link
- **The public app files no longer contain any of your real data.** A fresh visit to the link (or a brand-new device) now shows a completely empty app — no history, no balances, no amounts. Your actual data only ever appears after signing in with your Firebase email/password, or by importing a JSON backup you created yourself.
- **Optional app-lock PIN.** In Settings → App lock, you can set a 4-digit PIN that's required every time the app is opened — on this device or any other. It's a casual-visitor deterrent (everything is client-side, so it's not meant to stop a determined attacker with developer tools), not a replacement for the Firebase login, which is what actually protects your cloud data.
- **Restoring data without cloud sync:** Settings → Data now has an **Import data from JSON backup** button, for moving your data to a new device using an export file instead of cloud sync, if you'd rather not set up Firebase.
- Your real Firebase login (email/password) is still the only thing that can read or write your actual cloud-synced data — that hasn't changed.

## What's inside the app
- **Dashboard** — net worth (cash + unit trust + other assets − loans), your savings goal progress, all account balances, a 6-month income vs expense trend, and a monthly income/expense breakdown — calculated live from your transactions, exactly like your old Dashboard tab.
- **+ button** — add Income, add Expense, record an inter-account Transfer, or log a monthly Net Worth snapshot (for investments, property, and loans that aren't day-to-day transactions).
- **History** — every record, searchable, with swipe-free tap-to-delete.
- **Settings** — edit your savings goal, add new accounts or assets, export everything as a JSON backup, or reset.

## Where your data lives
Everything is stored locally on your phone's browser storage — nothing is sent to any server. Use **Settings → Export data as JSON** every so often as a backup, especially before clearing your browser data or switching phones.

## Notes on the numbers
- Bank/account balances are calculated automatically from every income and expense entry you log (plus the opening balances from your sheet), so they always stay in sync — you never need to manually update them.
- Unit trust accounts (Versa, StashAway, Wahed, Shares), other assets (KWSP, car, land, etc.) and your car loan are monthly manual entries, same as your old Networth tab, since those values don't come from daily transactions.
- Your historical monthly net worth snapshots (2020–Jun 2026) were imported from your Networth tab so your trend history isn't lost.
